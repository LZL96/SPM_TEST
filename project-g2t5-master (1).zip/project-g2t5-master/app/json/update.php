<?php
require_once '../include/common.php';
require_once '../include/protect.php';
require_once '../include/token.php';

$errors = [
            isMissingOrEmpty ('title'),
            isMissingOrEmpty ('isbn13'),
            isMissingOrEmpty ('price'),
            isMissingOrEmpty ('availability') 
        ];

// remove all the empty elements
$errors = array_filter($errors);
if(!isEmpty($errors)){

    $result = [
        "status" => "error",
        "message" => $errors
        ];

        //echo "yesssssssssssssssss";
}

else{

$dao = new BookDAO();

$book = new Book();
$book->title = $_GET['title'];
$book->isbn13 =  $_GET['isbn13'];
$book->price = $_GET['price'];
$book->availability = $_GET['availability'];


$errors = array_merge($errors,checkError($book,["title","isbn13","price","availability"]));
$errors = array_filter($errors);
}

if (isEmpty($errors)) {
	$dao->modify($book);
	$result = [
        "status" => "success",
        "book" => $book
        ];
}
else{
	 $result = [
        "status" => "error",
        "message" => $errors
        ];
}
header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
?>