<?php
require_once '../include/common.php';

require_once '../include/token.php';

$errors = [ isMissingOrEmpty ('title'), 
            isMissingOrEmpty ('isbn13'),
            isMissingOrEmpty ('price'),
            isMissingOrEmpty ('availability') ];

$errors = array_filter($errors);
 //print_r($_GET);
if(!isEmpty($errors)){

    $result = [
        "status" => "error",
        "message" => $errors
        ];

        //echo "yesssssssssssssssss";
}



else{
	// echo "yesssssssssssssssss";

    $dao = new BookDAO();
    $book = new Book();
    $book->title = $_GET['title'];
    $book->isbn13 =  $_GET['isbn13'];
    $book->price = $_GET['price'];
    $book->availability = $_GET['availability'];
    $test = $dao->retrieve($_GET['isbn13']);
    $errors = checkError($book, ["title","isbn13","price","availability"]);
    	//echo $test ;
    	//echo $book->price;
    	//print_r($book);

    	//echo "????";	
    	//print_r($dao->retrieve('97805960061232')->isbn13);
    if ($dao->retrieve($book->isbn13)) {
    $errors[] = "duplicate ISBN13 record";
    }

    //print_r($dao->retrieve('9780596006815'));


    $errors = array_filter($errors);

}
if (isEmpty($errors)) {
	$dao->add($book);
	$result = [
        "status" => "success",
        "book" => $book
        ];
}
else{

    $result = [
        "status" => "error",
        "message" => $errors
        ];

        //echo "yesssssssssssssssss";
}

// echo 'errors: ';
// print_r($errors);

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
?>