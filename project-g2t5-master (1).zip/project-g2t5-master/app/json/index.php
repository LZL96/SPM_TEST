<html>
<body>
    <table border='1'>
    <tr>
        <th>JSON API</th>
        <th>Description or form to test</th>
    </tr>
    <tr>
        <th>authenticate</th>
        <td>
            <form action="authenticate.php" method="post">
                Username: <input name="username" value="apple" /><br/>
                Password: <input type="password" name="password" value="apple123" /><br/>
                    <input type="submit">
            </form>
        </td>
    </tr>
    <tr>
        <th>read all</th>
        <td>
            <form action="read_all.php" method="get">
                    <input type="hidden" name="token" value="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6ImFwcGxlIiwiZGF0ZXRpbWUiOiIyMDE4LTA4LTIwIDIwOjEwOjM1In0._Nt2kOGEO36AyLf6n04TsPNcChUkTT01a0MLV89tuRE" />
                    <input type="submit">
            </form>
        </td>
    </tr>
    
    </table>
</body>
</html>