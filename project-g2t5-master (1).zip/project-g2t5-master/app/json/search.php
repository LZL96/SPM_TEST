<?php
require_once '../include/common.php';

require_once '../include/token.php';


$errors = [ isMissingOrEmpty ('search'),
            isMissingOrEmpty ('from'),
            isMissingOrEmpty ('to') ];

$errors = array_filter($errors);

// if (isset($_GET['keyword']) ) {
// 	echo "keyword is set     ";
// }

// if (empty($_GET['keyword']) && $_GET['keyword']==null ) {
// 	echo "empty     ";
// }




 //print_r($_GET);
if(!isEmpty($errors)){

    $result = [
        "status" => "error",
        "messages" => $errors
        ];

        //echo "yesssssssssssssssss";
}
//print_r($_GET['search']);
else{
	$dao = new BookDAO();
    $book = new Book();
    $allbooks = $dao->retrieveAll();
    $keyword = $_GET['keyword'];
    $search = $_GET['search'];
    $from = $_GET['from'];
    $to = $_GET['to'];

    //echo "$keyword";
//print_r($allbooks);

// foreach ($allbooks as $key => $value) {
// 	print_r($value);

// }
	$searchresult = [];
    foreach ($allbooks as $object ) {
    	$title = $object->title;
    	$isbn13 = $object->isbn13;
    	$price = $object->price;
    	$availability = $object->availability;
    	

    	if (empty($_GET['keyword']) && $_GET['keyword']==null ) {
    		if ($search == 'price') {
    			//echo "a";
	    		if (($price >= $from) && ($price <= $to) ) {
	    			//echo "b";
	    			$searchresult[] = $object; 
		    		}
	    	}

    		else{
	    		if (($availability >= $from) && ($availability <= $to) ) {
	    			$searchresult[] = $object;
	    			}
    		}
    	}

    	else{


	    	if ($search == 'price') {
	    		echo "a";

	    		if ((strpos(strtolower($title), $keyword) !== false) && ($price >= $from) && ($price <= $to) ) {
	    			echo "b";
	    			$searchresult[] = $object;
	    		}
	    	}
	    	else{
	    		
	    		if ((strpos(strtolower($title), $keyword) !== false) && ($availability >= $from) && ($availability <= $to) ) {

	    			$searchresult[] = $object;
	    		}
	    	}

    }





    }
    if(empty($searchresult)){
	$errors[] = "no item found";
	$result = [
        "status" => "error",
        "messages" => $errors
        ];
}
else{
	$result = [
        "status" => "success",
        "storeid" => 0,
        "result" => $searchresult
        ];
}
}




header('Content-Type: application/json');

echo json_encode($result, JSON_PRETTY_PRINT);
?>

