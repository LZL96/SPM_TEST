<?php
require_once '../include/common.php';
require_once '../include/protect.php';
require_once '../include/token.php';

$errors = [isMissingOrEmpty ('isbn13'),
            ];

//print_r($errors);
if(!isEmpty($errors)){

    $result = [
        "status" => "error",
        "message" => $errors
        ];

        //echo "yesssssssssssssssss";
}
else{
$book = new Book();
$dao = new BookDAO();
$book->isbn13 =  $_GET['isbn13'];

$errors = array_merge($errors,checkError($book,["isbn13record","isbn13"]));
$errors = array_filter($errors);
print_r($errors);

// echo $_GET['isbn13'];
}

if (isEmpty($errors)) {
	$dao->remove($_GET['isbn13']);
	$result = [
        "status" => "success",
        "isbn13" => $book->isbn13
        ];
}

else{
	$errors = array_filter($errors);
    $result = [
        "status" => "error",
        "message" => $errors
        ];

        //echo "yesssssssssssssssss";
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
?>