<?php

require_once '../include/common.php';
require_once '../include/protect.php';
require_once '../include/token.php';


$dao = new BookDAO();
$list = $dao->retrieveAll();


foreach ($list as $book ) {
	 $isbn_list[]=$book->isbn13;
	   }
// print_r($_POST);
// print_r($_GET);
// print_r($list);
// print_r($isbn_list);



// echo "$ISBN";
// print_r($errors);
// print_r($_REQUEST);

$errors = [isMissingOrEmpty ('isbn13')];
$errors = array_filter($errors);

if(!isEmpty($errors)){

    $result = [
        "status" => "error",
        "message" => $errors
        ];

        //echo "yesssssssssssssssss";
}

else{
      $ISBN = $_GET['isbn13'];
      if(!in_array($ISBN, $isbn_list) && !empty($ISBN)){
      	$errors[]= "ISBN does not exist";
        $result = [
        "status" => "error",
        "message" => $errors
        ];
      	
      }



      else {
      	$retrived_book = $dao -> retrieve($ISBN);
      	$title = $retrived_book->title;
      	// echo "ISBN: $ISBN";
      	// echo "<br>";
      	// echo "book: $title";
      	$result = [
              "status" => "success",
              "book" => $retrived_book
              ];
      }
}




header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);


?>