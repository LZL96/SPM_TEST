<?php

require_once 'include/common.php';
require_once 'include/token.php';

// isMissingOrEmpty(...) is in common.php
$errors = [ isMissingOrEmpty ('username'), isMissingOrEmpty ('password') ];
$errors = array_filter($errors);


if (!isEmpty($errors)) {
    $_SESSION['errors'] = $errors;
    include "login-view.php";
    exit();
}

$username = $_POST['username'];
$enteredPwd = $_POST['password'];



$dao = new UserDAO();
$user = $dao->retrieve($username);


if ($username == "admin" && $enteredPwd == "admin"){
	$_SESSION['admin'] = 1;
	$user->name = "Admin";
	$user->gender = "male";
	$user->username="admin";
	$_SESSION['user'] = $user;
	$token = generate_token($username);
    $_SESSION['token'] = $token;
	header("Location: list-view.php");
}    
elseif (isset($user) && $user->authenticate($enteredPwd)) {
	$_SESSION['admin'] = 0;
    $_SESSION['user'] = $user;
    $token = generate_token($username);
    $_SESSION['token'] = $token;
    header("Location: list-view.php");
} else {
    $_SESSION['errors'] = [ 'Username/password is incorrect' ];
    include 'login-view.php';
}
?>