<?php
# address to host and site name

$host = array('http://localhost:80/bookstore-basic','http://localhost:80/bookstore2','http://localhost:80/bookstore3'); 
$storeid = 0;
$server = "localhost";
$username = "root";
$password = "";  
$dbname = "bookstore";
$port = 3306;    

?>
